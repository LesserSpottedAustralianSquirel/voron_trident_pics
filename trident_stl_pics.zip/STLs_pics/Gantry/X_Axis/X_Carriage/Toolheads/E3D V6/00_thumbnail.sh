for i in *.stl; do
  T=__tmp__$i
  b=`basename $i`
  echo import\(\"$i\"\)\; >$T
  /media/sgeorge/EXTERNAL_HD/USB_LIB_stick/000_desktop/openscad/OpenSCAD-2021.01-x86_64.AppImage -o $b.png --imgsize=100,100 $T
  rm $T
done
